#include "scheduler.h"
#include "main.h"

void SCH_Init(void) {
    unsigned char i;
    for (i = 0; i < SCH_MAX_TASKS; i++) {
    	SCH_Delete_Task (i) ;
    }
}

void SCH_Update( void ) {
	unsigned char Index ;
	// NOTE: calculations are in *TICKS*
	for ( Index = 0 ; Index < SCH_MAX_TASKS; Index++) {
	// Check i f there i s a task at t h i s location
		if ( SCH_tasks_G [ Index ].pTask ) {
			if ( SCH_tasks_G [ Index ].Delay == 0) {
			// The task i s due to run
			// Inc . the ’RunMe’ f l a g
			SCH_tasks_G [ Index ].RunMe += 1 ;
			if ( SCH_tasks_G [ Index ].Period ) {
			// Schedule periodic tasks to run again
			SCH_tasks_G[ Index ].Delay = SCH_tasks_G [Index].Period ;
			}
			} else {
			// Not yet ready to run : j u s t decrement the delay
			SCH_tasks_G[Index].Delay -= 1 ;
			}
		}
	}
}


unsigned char SCH_Add_Task(void (*pFunction)(), unsigned int DELAY, unsigned int PERIOD)
{
	unsigned char Index = 0 ;
// F i r s t find a gap in the a r r a y ( i f th e r e i s one )
	while ( ( SCH_tasks_G[Index].pTask != 0 ) && ( Index < SCH_MAX_TASKS ) )
 {
 Index ++;
 }
 // Have we reached the end o f the l i s t ?
 if( Index == SCH_MAX_TASKS )
 {
 // Task l i s t i s f u l l
 // Se t the gl ob al e r r o r v a ri a bl e
 // Also r e tu rn an e r r o r code
 return SCH_MAX_TASKS ;
 }
 // I f we ’ re here , th e r e i s a space in the t a s k a r r a y
 SCH_tasks_G [ Index ] . pTask = pFunction ;
 SCH_tasks_G [ Index ] . Delay = DELAY ;
 SCH_tasks_G [ Index ] . Period = PERIOD ;
 SCH_tasks_G [ Index ] . RunMe = 0 ;
 // r e tu rn p o si ti on o f t a s k ( to allow l a t e r d el e ti on )
 return Index ;
 }

void SCH_Dispatch_Tasks(void)
{
		// Dispa tches ( runs ) the nex t t a s k ( i f one i s ready )
        if (SCH_tasks_G[0].RunMe > 0) {
            (*SCH_tasks_G[0].pTask)(); // Run the task
            SCH_tasks_G[0].RunMe -= 1; // Reset / reduce RunMe flag
            // Periodic tasks will automatically run again
            // - if this is a 'one shot' task, remove it from the array
            if (SCH_tasks_G[0].Period == 0)
            {
                SCH_Delete_Task(0);
            }
            else{
            	sTask buffer = SCH_tasks_G[0];
            	SCH_Delete_Task(0);
            	SCH_Add_Task(buffer.pTask, buffer.Delay , buffer.Period);
            }
        }
}

unsigned char SCH_Delete_Task(const int TASK_INDEX){
    unsigned char Return_code;
		//delete the task at position 0 and move the following tasks to 1 position
    Return_code = 0;
    SCH_tasks_G[TASK_INDEX].pTask = 0x0000;
    SCH_tasks_G[TASK_INDEX].Delay = 0;
    SCH_tasks_G[TASK_INDEX].Period = 0;
    SCH_tasks_G[TASK_INDEX].RunMe = 0;
    return Return_code; // return status
}
