/*
 * blink.c
 *
 *  Created on: Dec 11, 2021
 *      Author: viett
 */

#include "main.h"
#include "blink.h"

void blink1(){
	HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
}

void blink2(){
	HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
}

void blink3(){
	HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);
}

void blink4(){
	HAL_GPIO_TogglePin(LED4_GPIO_Port, LED4_Pin);
}

void blink5(){
	HAL_GPIO_TogglePin(LED5_GPIO_Port, LED5_Pin);
}
