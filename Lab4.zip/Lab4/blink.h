/*
 * blink.h
 *
 *  Created on: Dec 11, 2021
 *      Author: viett
 */

#ifndef INC_BLINK_H_
#define INC_BLINK_H_

void blink1(void);
void blink2(void);
void blink3(void);
void blink4(void);
void blink5(void);

#endif /* INC_BLINK_H_ */
