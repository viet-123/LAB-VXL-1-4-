/*
 * input_processing.h
 *
 *  Created on: Oct 11, 2021
 *      Author: viett
 */

#ifndef INC_INPUT_PROCESSING_H_
#define INC_INPUT_PROCESSING_H_

void fsm_for_input_processing(void);

#endif /* INC_INPUT_PROCESSING_H_ */
