/*
 * input_processing.c
 *
 *  Created on: Oct 11, 2021
 *      Author: viett
 */
#include "main.h"
#include "input_reading.h"
#include "led7.h"

int RED = 5, GREEN = 3, YELLOW = 2;
#define MODE1  0
#define MODE2  1
#define MODE3  2
#define MODE4  3
int mode = 0;
int num,num1;
int count = 4; //4*250ms = 1secs..
int timeL = 10;// den giao thong mac dinh 1 chu ki = 5 + 3 + 2
int blink_2Hz = 2; // 250ms on, 250ms off --> f = 2Hz
int tRED = 0;
int tGREEN = 0;
int tYELLOW = 0;

void fsm_for_input_processing(void) {
	switch(mode){
		case MODE1:
			if(timeL == RED + GREEN + YELLOW){
				num = RED;
				num1 = GREEN;
				displayLED(0);
				displayLED1(1);
			}
			if(timeL == RED + YELLOW){
				num1 = YELLOW;
				displayLED1(2);
			}
			if(timeL == RED){
				num = GREEN;
				num1 = RED;
				displayLED(1);
				displayLED1(0);
			}
			if(timeL == YELLOW){
				num = YELLOW;
				displayLED(2);
			}
			if(count == 4) display2SEG7(num,num1);
			count--;
			if(count == 2) display2SEG7(num,num1);
			if(count == 0){
				timeL--;
				count = 4;
				num--;num1--;
			}
			if(timeL== 0) timeL = RED + GREEN + YELLOW;

			if(timeL < RED + GREEN + YELLOW){
			if(is_button_pressed(0)){
				mode = MODE2;
			}
			}
			break;
		case MODE2:
			if(blink_2Hz==2){
				displayLED(0);
				displayLED1(0);
				HAL_GPIO_WritePin(aa0_GPIO_Port, aa0_Pin, SET);
				HAL_GPIO_WritePin(aa1_GPIO_Port, aa1_Pin, RESET);
				HAL_GPIO_WritePin(bb0_GPIO_Port, bb0_Pin, SET);
				HAL_GPIO_WritePin(bb1_GPIO_Port, bb1_Pin, RESET);
				int a0 = tRED / 10;
				display7SEG(a0);
				display7SEG1(0);
			}

			if(is_button_pressed(1)){
				tRED++;
			}
			if(tRED > 99) tRED = 0;
			if(blink_2Hz==1){
				displayLED(-1);
				displayLED1(-1);
				HAL_GPIO_WritePin(aa0_GPIO_Port, aa0_Pin, RESET);
				HAL_GPIO_WritePin(aa1_GPIO_Port, aa1_Pin, SET);
				HAL_GPIO_WritePin(bb0_GPIO_Port, bb0_Pin, RESET);
				HAL_GPIO_WritePin(bb1_GPIO_Port, bb1_Pin, SET);
				int a1 = tRED % 10;
				display7SEG(a1);
				display7SEG1(2);
			}
			blink_2Hz--;
			if(blink_2Hz == 0){
				blink_2Hz = 2;
			}
			if(is_button_pressed(2)){
				RED = tRED;
			}
			if(is_button_pressed(0)){
				mode = MODE3;
				tRED = 0;
			}
			break;
		case MODE3:
			if(blink_2Hz==2){
				displayLED(2);
				displayLED1(2);
				HAL_GPIO_WritePin(aa0_GPIO_Port, aa0_Pin, SET);
				HAL_GPIO_WritePin(aa1_GPIO_Port, aa1_Pin, RESET);
				HAL_GPIO_WritePin(bb0_GPIO_Port, bb0_Pin, SET);
				HAL_GPIO_WritePin(bb1_GPIO_Port, bb1_Pin, RESET);
				int c0 = tYELLOW / 10;
				display7SEG(c0);
				display7SEG1(0);
			}
			if(is_button_pressed(1)){
				tYELLOW++;
			}
			if(tYELLOW > 99) tYELLOW = 0;
			if(blink_2Hz==1){
				displayLED(-1);
				displayLED1(-1);
				HAL_GPIO_WritePin(aa0_GPIO_Port, aa0_Pin, RESET);
				HAL_GPIO_WritePin(aa1_GPIO_Port, aa1_Pin, SET);
				HAL_GPIO_WritePin(bb0_GPIO_Port, bb0_Pin, RESET);
				HAL_GPIO_WritePin(bb1_GPIO_Port, bb1_Pin, SET);
				int c1 = tYELLOW % 10;
				display7SEG(c1);
				display7SEG1(3);
			}
			blink_2Hz--;
			if(blink_2Hz == 0){
				blink_2Hz = 2;
			}
			if(is_button_pressed(2)){
				YELLOW = tYELLOW;
			}
			if(is_button_pressed(0)){
				mode = MODE4;
				tYELLOW = 0;
			}
			break;
		case MODE4:
			if(blink_2Hz==2){
				displayLED(1);
				displayLED1(1);
				HAL_GPIO_WritePin(aa0_GPIO_Port, aa0_Pin, SET);
				HAL_GPIO_WritePin(aa1_GPIO_Port, aa1_Pin, RESET);
				HAL_GPIO_WritePin(bb0_GPIO_Port, bb0_Pin, SET);
				HAL_GPIO_WritePin(bb1_GPIO_Port, bb1_Pin, RESET);
				int b0 = tGREEN / 10;
				display7SEG(b0);
				display7SEG1(0);
			}

			if(is_button_pressed(1)){
				tGREEN++;
			}
			if(tGREEN > 99) tGREEN = 0;
			if(blink_2Hz==1){
				displayLED(-1);
				displayLED1(-1);
				HAL_GPIO_WritePin(aa0_GPIO_Port, aa0_Pin, RESET);
				HAL_GPIO_WritePin(aa1_GPIO_Port, aa1_Pin, SET);
				HAL_GPIO_WritePin(bb0_GPIO_Port, bb0_Pin, RESET);
				HAL_GPIO_WritePin(bb1_GPIO_Port, bb1_Pin, SET);
				int b1 = tGREEN % 10;
				display7SEG(b1);
				display7SEG1(4);
			}
			blink_2Hz--;
			if(blink_2Hz == 0){
				blink_2Hz = 2;
			}
			if(is_button_pressed(2)){
				GREEN = tGREEN;
			}
			if(is_button_pressed(0)){
				mode = MODE1;
				tGREEN = 0;
			}
			timeL = RED + GREEN + YELLOW;
			break;

	}
}


