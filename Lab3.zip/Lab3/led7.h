/*
 * led7.h
 *
 *  Created on: Dec 11, 2021
 *      Author: viett
 */

#ifndef INC_LED7_H_
#define INC_LED7_H_

void display7SEG ( int num ) ; //cột dọc

void display7SEG1 ( int num ) ;//cột ngang

void display2SEG7 (int num,int num1);

void displayLED ( int num ) ; //cột dọc

void displayLED1 ( int num ) ;//cột ngang

#endif /* INC_LED7_H_ */
