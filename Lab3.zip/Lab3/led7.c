/*
 * led7.c
 *
 *  Created on: Dec 11, 2021
 *      Author: viett
 */

#include "main.h"
#include "led7.h"
#include "input_processing.h"

void display7SEG(int num){
	  switch(num){
	  case 0:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,SET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,RESET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,RESET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,RESET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,RESET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,RESET);
		  break;
	  case 1:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,SET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,SET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,SET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,SET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,RESET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,SET);
		  break;
	  case 2:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,RESET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,SET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,RESET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,RESET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,SET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,RESET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,RESET);
		  break;
	  case 3:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,RESET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,SET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,SET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,RESET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,RESET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,RESET);
		  break;
	  case 4:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,RESET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,RESET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,SET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,SET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,RESET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,SET);
		  break;
	  case 5:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,RESET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,RESET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,SET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,RESET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,SET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,RESET);
		  break;
	  case 6:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,RESET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,RESET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,RESET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,RESET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,SET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,RESET);
		  break;
	  case 7:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,SET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,SET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,SET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,SET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,RESET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,RESET);
		  break;
	  case 8:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,RESET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,RESET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,RESET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,RESET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,RESET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,RESET);
		  break;
	  case 9:
		  HAL_GPIO_WritePin(a6_GPIO_Port, a6_Pin,RESET);
		  HAL_GPIO_WritePin(a5_GPIO_Port, a5_Pin,RESET);
		  HAL_GPIO_WritePin(a4_GPIO_Port, a4_Pin,SET);
		  HAL_GPIO_WritePin(a3_GPIO_Port, a3_Pin,RESET);
		  HAL_GPIO_WritePin(a2_GPIO_Port, a2_Pin,RESET);
		  HAL_GPIO_WritePin(a1_GPIO_Port, a1_Pin,RESET);
		  HAL_GPIO_WritePin(a0_GPIO_Port, a0_Pin,RESET);
		  break;
	  }
  }
void display7SEG1(int num){
	  switch(num){
	  case 0:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,SET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,RESET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,RESET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,RESET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,RESET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,RESET);
		  break;
	  case 1:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,SET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,SET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,SET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,SET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,RESET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,SET);
		  break;
	  case 2:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,RESET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,SET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,RESET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,RESET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,SET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,RESET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,RESET);
		  break;
	  case 3:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,RESET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,SET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,SET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,RESET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,RESET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,RESET);
		  break;
	  case 4:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,RESET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,RESET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,SET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,SET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,RESET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,SET);
		  break;
	  case 5:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,RESET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,RESET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,SET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,RESET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,SET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,RESET);
		  break;
	  case 6:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,RESET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,RESET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,RESET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,RESET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,SET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,RESET);
		  break;
	  case 7:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,SET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,SET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,SET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,SET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,RESET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,RESET);
		  break;
	  case 8:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,RESET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,RESET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,RESET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,RESET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,RESET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,RESET);
		  break;
	  case 9:
		  HAL_GPIO_WritePin(b6_GPIO_Port, b6_Pin,RESET);
		  HAL_GPIO_WritePin(b5_GPIO_Port, b5_Pin,RESET);
		  HAL_GPIO_WritePin(b4_GPIO_Port, b4_Pin,SET);
		  HAL_GPIO_WritePin(b3_GPIO_Port, b3_Pin,RESET);
		  HAL_GPIO_WritePin(b2_GPIO_Port, b2_Pin,RESET);
		  HAL_GPIO_WritePin(b1_GPIO_Port, b1_Pin,RESET);
		  HAL_GPIO_WritePin(b0_GPIO_Port, b0_Pin,RESET);
		  break;
	  }
  }

void displayLED ( int num ){
	switch(num){
		case 0: //red
			HAL_GPIO_WritePin(r1_GPIO_Port, r1_Pin, RESET);
			HAL_GPIO_WritePin(g1_GPIO_Port, g1_Pin, SET);
			HAL_GPIO_WritePin(y1_GPIO_Port, y1_Pin, SET);
			break;
		case 1: //green
			HAL_GPIO_WritePin(r1_GPIO_Port, r1_Pin, SET);
			HAL_GPIO_WritePin(g1_GPIO_Port, g1_Pin, RESET);
			HAL_GPIO_WritePin(y1_GPIO_Port, y1_Pin, SET);
			break;
		case 2:	//yellow
			HAL_GPIO_WritePin(r1_GPIO_Port, r1_Pin, SET);
			HAL_GPIO_WritePin(g1_GPIO_Port, g1_Pin, SET);
			HAL_GPIO_WritePin(y1_GPIO_Port, y1_Pin, RESET);
			break;
		default: //turn off
			HAL_GPIO_WritePin(r1_GPIO_Port, r1_Pin, SET);
			HAL_GPIO_WritePin(g1_GPIO_Port, g1_Pin, SET);
			HAL_GPIO_WritePin(y1_GPIO_Port, y1_Pin, SET);
			break;
	}
}

void displayLED1 ( int num ){
	switch(num){
		case 0: //red
			HAL_GPIO_WritePin(r2_GPIO_Port, r2_Pin, RESET);
			HAL_GPIO_WritePin(g2_GPIO_Port, g2_Pin, SET);
			HAL_GPIO_WritePin(y2_GPIO_Port, y2_Pin, SET);
			break;
		case 1: //green
			HAL_GPIO_WritePin(r2_GPIO_Port, r2_Pin, SET);
			HAL_GPIO_WritePin(g2_GPIO_Port, g2_Pin, RESET);
			HAL_GPIO_WritePin(y2_GPIO_Port, y2_Pin, SET);
			break;
		case 2:	//yellow
			HAL_GPIO_WritePin(r2_GPIO_Port, r2_Pin, SET);
			HAL_GPIO_WritePin(g2_GPIO_Port, g2_Pin, SET);
			HAL_GPIO_WritePin(y2_GPIO_Port, y2_Pin, RESET);
			break;
		default: //turn off
			HAL_GPIO_WritePin(r2_GPIO_Port, r2_Pin, SET);
			HAL_GPIO_WritePin(g2_GPIO_Port, g2_Pin, SET);
			HAL_GPIO_WritePin(y2_GPIO_Port, y2_Pin, SET);
			break;
	}
}

int index = 0;
void display2SEG7 (int num,int num1){
	switch(index){
		case 0:
			HAL_GPIO_WritePin(aa0_GPIO_Port,aa0_Pin,SET);
			HAL_GPIO_WritePin(aa1_GPIO_Port,aa1_Pin,RESET);
			HAL_GPIO_WritePin(bb0_GPIO_Port,bb0_Pin,SET);
			HAL_GPIO_WritePin(bb1_GPIO_Port,bb1_Pin,RESET);
			display7SEG(num / 10);
			display7SEG1(num1 / 10);
			index = 1;
			break;
		case 1:
			HAL_GPIO_WritePin(aa0_GPIO_Port,aa0_Pin,RESET);
			HAL_GPIO_WritePin(aa1_GPIO_Port,aa1_Pin,SET);
			HAL_GPIO_WritePin(bb0_GPIO_Port,bb0_Pin,RESET);
			HAL_GPIO_WritePin(bb1_GPIO_Port,bb1_Pin,SET);
			display7SEG(num % 10);
			display7SEG1(num1 % 10);
			index = 0;
			break;
		default:
			break;
	}

}


